TayfTech — حزمة النشر على Cloudflare (مجانية ضمن حدود الخطط المجانية)

محتويات الحزمة:
- public/index.html: واجهة الزبائن ولوحة الإدارة.
- src/index.js: واجهة API الخلفية (Worker).
- schema.sql: جداول المنتجات والطلبات والإعدادات.
- wrangler.toml: إعدادات النشر والربط.

مهم جداً:
هذه ليست حزمة تُرفع عبر زر "Upload static files" وحده؛ لأن المتجر يحتاج API وقاعدة بيانات وصوراً. يجب نشر المشروع كـ Worker مع Static Assets باستخدام Wrangler. لا تضع كلمة مرور الإدارة داخل الملفات أو ترسلها في الدردشة.

الإعداد مرة واحدة:
1) من Cloudflare افتح Workers & Pages ثم أنشئ D1 database باسم tayftech-db.
2) افتح قاعدة البيانات > Console، والصق محتوى schema.sql ثم نفّذه.
3) أنشئ R2 bucket باسم tayftech-images.
4) انسخ Database ID من صفحة D1 وضعه مكان PUT_D1_DATABASE_ID_HERE في wrangler.toml.
5) على كمبيوتر (أسهل من الهاتف) ثبّت Node.js ثم نفّذ:
   npm install -g wrangler
   wrangler login
   wrangler secret put ADMIN_PASSWORD
   (اكتب كلمة مرور قوية عند الطلب)
   wrangler secret put ADMIN_SECRET
   (أدخل قيمة عشوائية طويلة جداً لا تقل عن 32 حرفاً)
   wrangler deploy

سيطلب Wrangler صلاحيات ربط D1 وR2 حسب إعداد الحساب. بعد النشر يعطيك رابط *.workers.dev.
إذا أردت نطاق Pages بدلاً منه، لا تستخدم رفع الملفات الثابتة وحده لهذا المشروع؛ انشر Worker مع Assets كما في الإعداد أعلاه.

تنبيه الأمان:
- واجهة الإدارة محمية بكلمة مرور وتوكن مؤقت 12 ساعة.
- لا تشارك ADMIN_PASSWORD أو ADMIN_SECRET.
- الطلبات العامة تسمح للزبائن بإنشاء طلبات فقط، ولا تسمح لهم بقراءة الطلبات أو تعديل المنتجات.
- لا ترفع ملفات أكبر من 5MB للصور.
- استخدم HTTPS، واختبر الموقع من شبكات سورية مختلفة قبل الإعلان عنه.

الحدود المجانية ليست غير محدودة وقد تتغير. راجع لوحة Cloudflare الرسمية للاستهلاك وحدود D1 وR2 وWorkers.
