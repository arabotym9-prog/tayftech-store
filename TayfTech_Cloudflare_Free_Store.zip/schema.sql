CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 description TEXT DEFAULT '',
 price REAL NOT NULL DEFAULT 0,
 image_url TEXT DEFAULT '',
 visible INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 note TEXT DEFAULT '',
 items_json TEXT NOT NULL,
 total REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'جديد',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL DEFAULT ''
);
INSERT OR IGNORE INTO settings(key,value) VALUES
 ('whatsapp',''),('facebook',''),('instagram',''),('about','');
